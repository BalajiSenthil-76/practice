package hexaware.Carconnect.Exception;

public class AdminNotFoundException extends Exception{
	public AdminNotFoundException(String message) {
        super(message);
    }

}
