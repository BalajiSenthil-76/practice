package hexaware.Carconnect.dao;

import java.sql.SQLException;
import java.util.List;

import hexaware.Carconnect.Exception.AdminNotFoundException;
import hexaware.Carconnect.model.Admin;



public interface admindao {
	List<Admin> Showadmin() throws SQLException, ClassNotFoundException;
	Admin GetAdminById(int adminID) throws SQLException, ClassNotFoundException;
	Admin GetAdminByUsername(String username) throws ClassNotFoundException, SQLException;
	int authenticateAdmin(String user,String pwd) throws ClassNotFoundException, SQLException;
	Admin  UpdateAdmin(Admin admin4) throws ClassNotFoundException, SQLException;
	String  DeleteAdmin(int adminID ) throws ClassNotFoundException, SQLException, AdminNotFoundException;
}
