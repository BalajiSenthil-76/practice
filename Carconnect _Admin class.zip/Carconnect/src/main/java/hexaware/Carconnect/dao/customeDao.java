package hexaware.Carconnect.dao;

import java.sql.SQLException;
import java.util.List;

import hexaware.Carconnect.model.Customer;

public interface customeDao {
		List<Customer> showCustomerDao() throws ClassNotFoundException, SQLException;
}
