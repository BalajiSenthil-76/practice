package hexaware.Carconnect.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import hexaware.Carconnect.model.Customer;
import hexaware.Carconnect.util.DbPropertUtil;
import hexaware.Carconnect.util.DbConnUtil;

public class customerDaoimpl implements customeDao{
	Connection connection;
	PreparedStatement pst;
	
	public List<Customer> showCustomerDao() throws ClassNotFoundException, SQLException {
		String connStr=DbPropertUtil.Connectionstring("db");
		connection=hexaware.Carconnect.util.DbConnUtil.getConnection(connStr);
		
		String cmd="select * from customers";
		pst=connection.prepareStatement(cmd);
		ResultSet rs=pst.executeQuery();
		List<Customer> customerList=new ArrayList<Customer>();
		
//		a new ArrayList instance that can hold Customer objects and assigns it to the variable customerList,
//		which is declared to be of type List<Customer>.
		Customer customer=null;
		while(rs.next())
		{
			customer=new Customer();
			customer.setCustomerId(rs.getInt("CustomerId"));
			customer.setFirstName(rs.getString("firstname"));
			customer.setLastName(rs.getString("lastname"));
			customer.setEmail(rs.getString("email"));
			customer.setPhoneNumber(rs.getString("phone"));
			customer.setAddress(rs.getString("address"));
			
//			The JDBC API provides methods like getInt(), getString(), etc., to retrieve values from the result set based on the column name. These methods handle the type conversion internally, 
//			so you don't need to explicitly specify the data type when retrieving values.
			
//			Ensure that the column names provided in the getString method 
//			exactly match the column names in your database table
			customerList.add(customer);
			
		}
		return customerList;
	}
	
	
	

}
