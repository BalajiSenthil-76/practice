package hexaware.Carconnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import hexaware.Carconnect.Exception.AdminNotFoundException;
import hexaware.Carconnect.dao.Admindaoimpl;
import hexaware.Carconnect.dao.admindao;
import hexaware.Carconnect.model.Admin;

public class DeleteAdmin {
public static void main(String[] args) throws AdminNotFoundException {
	int adminID;
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the Admin ID you want ro delete:");
	adminID=sc.nextInt();
	
	admindao  dao=new Admindaoimpl();
	try {
		dao.DeleteAdmin(adminID);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
