package hexaware.Carconnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import hexaware.Carconnect.Exception.AdminNotFoundException;
import hexaware.Carconnect.dao.Admindaoimpl;
import hexaware.Carconnect.dao.admindao;
import hexaware.Carconnect.model.Admin;

public class GetAdminById {
public static void main(String[] args) throws AdminNotFoundException {
	int adminID;
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the Admin ID:");
	adminID=sc.nextInt();
	
	admindao  dao=new Admindaoimpl();
	 try {
		Admin admin2=dao.GetAdminById(adminID);
		if(admin2 !=null)
			System.out.println(admin2);
		else
			throw new AdminNotFoundException("**The Admin is not Registered");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
}
