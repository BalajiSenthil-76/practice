package hexaware.Carconnect.main;

import java.sql.SQLException;
import java.util.Scanner;

import hexaware.Carconnect.dao.Admindaoimpl;
import hexaware.Carconnect.dao.admindao;
import hexaware.Carconnect.model.Admin;

public class GetAdminByUsername {
	public static void main(String[] args) {
		 String username;
		Scanner sc=new Scanner (System.in);
		System.out.println("Enter the Username:");
		username=sc.next();
		
		admindao  dao=new Admindaoimpl();
		 try {
			Admin admin2=dao.GetAdminByUsername(username);
			if(admin2 !=null)
				System.out.println(admin2);
			else
				System.out.println("**Please enter valid Username");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	}

