package hexaware.Carconnect.main;

import java.sql.SQLException;
import java.util.List;

import hexaware.Carconnect.dao.Admindaoimpl;
import hexaware.Carconnect.dao.admindao;
import hexaware.Carconnect.model.Admin;

public class Showadmin {
	public static void main(String[] args) {
		admindao dao=new Admindaoimpl();
		try {
			List<Admin> adminlist=dao.Showadmin();
			for (Admin admin : adminlist) {
				System.out.println(admin);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
