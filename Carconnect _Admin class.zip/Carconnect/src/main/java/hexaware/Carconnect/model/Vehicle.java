package hexaware.Carconnect.model;

public class Vehicle {
	private int VehicleID; 
	private String Model; 
	private int brandMake;
	private int Year; 
	private String Color;
	private String RegistrationNumber;
	private String Availability; 
	private int DailyRate;
	public int getVehicleID() {
		return VehicleID;
	}
	public void setVehicleID(int vehicleID) {
		VehicleID = vehicleID;
	}
	public String getModel() {
		return Model;
	}
	public void setModel(String model) {
		Model = model;
	}
	public int getBrandMake() {
		return brandMake;
	}
	public void setBrandMake(int brandMake) {
		this.brandMake = brandMake;
	}
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		Year = year;
	}
	public String getColor() {
		return Color;
	}
	public void setColor(String color) {
		Color = color;
	}
	public String getRegistrationNumber() {
		return RegistrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		RegistrationNumber = registrationNumber;
	}
	public String getAvailability() {
		return Availability;
	}
	public void setAvailability(String availability) {
		Availability = availability;
	}
	public int getDailyRate() {
		return DailyRate;
	}
	public void setDailyRate(int dailyRate) {
		DailyRate = dailyRate;
	}
	public Vehicle() {
	
		// TODO Auto-generated constructor stub
	}
	public Vehicle(int vehicleID, String model, int brandMake, int year, String color, String registrationNumber,
			String availability, int dailyRate) {
		super();
		VehicleID = vehicleID;
		Model = model;
		this.brandMake = brandMake;
		Year = year;
		Color = color;
		RegistrationNumber = registrationNumber;
		Availability = availability;
		DailyRate = dailyRate;
	}
	@Override
	public String toString() {
		return "Vehicle [VehicleID=" + VehicleID + ", Model=" + Model + ", brandMake=" + brandMake + ", Year=" + Year
				+ ", Color=" + Color + ", RegistrationNumber=" + RegistrationNumber + ", Availability=" + Availability
				+ ", DailyRate=" + DailyRate + "]";
	}
	
	
	
	
	
	
}
