package hexaware.Carconnect.model;

import java.util.Date;

public class reservation {
	private int ReservationID;
	private int CustomerID;
	private int VehicleID;
	private Date StartDate;
	private Date EndDate;
	private int TotalCost; 
	private String Status;
	public int getReservationID() {
		return ReservationID;
	}
	public void setReservationID(int reservationID) {
		ReservationID = reservationID;
	}
	public int getCustomerID() {
		return CustomerID;
	}
	public void setCustomerID(int customerID) {
		CustomerID = customerID;
	}
	public int getVehicleID() {
		return VehicleID;
	}
	public void setVehicleID(int vehicleID) {
		VehicleID = vehicleID;
	}
	public Date getStartDate() {
		return StartDate;
	}
	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}
	public Date getEndDate() {
		return EndDate;
	}
	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}
	public int getTotalCost() {
		return TotalCost;
	}
	public void setTotalCost(int totalCost) {
		TotalCost = totalCost;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public reservation() {
	
		// TODO Auto-generated constructor stub
	}
	public reservation(int reservationID, int customerID, int vehicleID, Date startDate, Date endDate, int totalCost,
			String status) {
		
		ReservationID = reservationID;
		CustomerID = customerID;
		VehicleID = vehicleID;
		StartDate = startDate;
		EndDate = endDate;
		TotalCost = totalCost;
		Status = status;
	}
	@Override
	public String toString() {
		return "reservation [ReservationID=" + ReservationID + ", CustomerID=" + CustomerID + ", VehicleID=" + VehicleID
				+ ", StartDate=" + StartDate + ", EndDate=" + EndDate + ", TotalCost=" + TotalCost + ", Status="
				+ Status + "]";
	}
	
	
	
	

	
	
}
