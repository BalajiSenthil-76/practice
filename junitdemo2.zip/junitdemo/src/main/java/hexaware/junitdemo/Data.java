package hexaware.junitdemo;

public class Data {
	
	public int max3(int a, int b, int c) {
			int m = a;
			if (m < b) {
				m = b;
			}
			if (m < c) {
				m = c;
			}
			return m;
		}
		
		
		public int sum(int a, int b) {
			return a + b;
		}
		
		public String sayHello() {
			return "Welcome to Java Programming...";
		}
}
