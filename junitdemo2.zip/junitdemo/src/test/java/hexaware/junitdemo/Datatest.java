package hexaware.junitdemo;

import static org.junit.Assert.*;

import org.junit.Test;

public class Datatest {

	@Test
	public void testSayHello() {
		Data data5=new Data();
		assertEquals("Welcome to Java Programming...",data5.sayHello());
	}
	
	@Test
	public void testSum()
	{
		Data data1=new Data();
		assertEquals(5,data1.sum(2, 3));
	}
	
	@Test
	public void testmax3()
	{
		Data data3 =new Data();
		assertEquals(7, data3.max3(7, 5, 3));
		assertEquals(7, data3.max3(5, 7, 3));
		assertEquals(7, data3.max3(3, 5, 7));
	}

}
